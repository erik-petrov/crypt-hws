# -*- coding: UTF-8 -*-

##############################################################################
#                                                                            #
# Copyright (c) 2007-2010 Bernd Kreuss <prof7bit@gmail.com>                  #
#                                                                            #
# Translation file for TorChat                                               #
#                                                                            #
##############################################################################

LANGUAGE_CODE = u"es"
LANGUAGE_NAME = u"Español"
LANGUAGE_NAME_ENGLISH = u"Spanish"
TRANSLATOR_NAMES = ['Dererk']

#buttons
BTN_CANCEL = u"Cancelar"
BTN_OK = u"Ok"
BTN_SAVE_AS = u"Guardar como..."
BTN_CLOSE = u"Cerrar"

#status
ST_AVAILABLE = u"Disponible"
ST_AWAY = u"Ausente"
ST_EXTENDED_AWAY = u"Ausencia extendida"
ST_OFFLINE = u"Desconectado"

#TaskbarMenu
MTB_SHOW_HIDE_TORCHAT = u"Mostrar/Ocultar TorChat"
MTB_QUIT = u"Salir"

#popup menu
MPOP_CHAT = u"Chat..."
MPOP_SEND_FILE = u"Enviar archivo..."
MPOP_EDIT_CONTACT = u"Editar contacto..."
MPOP_DELETE_CONTACT = u"Eliminar contacto..."
MPOP_SHOW_OFFLINE_MESSAGES = u"Mostrar cola de mensajes sin conexión"
MPOP_CLEAR_OFFLINE_MESSAGES = u"Limpiar cola de mensajes sin conexión"
MPOP_ACTIVATE_LOG = u"Activar escritura de eventos a un archivo"
MPOP_STOP_LOG = u"Detener escritura de eventos"
MPOP_DELETE_EXISTING_LOG = u"Eliminar archivo de eventos existente"
MPOP_DELETE_AND_STOP_LOG = u"Detener la escritura de eventos y eliminar el archivo"
MPOP_ADD_CONTACT = u"Agregar contacto..."
MPOP_ABOUT = u"Acerca de TorChat"
MPOP_ASK_AUTHOR = u"Preguntar a %s..."
MPOP_SETTINGS = u"Propiedades..."
MPOP_EDIT_MY_PROFILE = u"Editar mi perfil..."

#chat window popup menu
CPOP_COPY = u"Copiar"

#confirm delete message box
D_CONFIRM_DELETE_TITLE = u"Confirmar eliminación"
D_CONFIRM_DELETE_MESSAGE = u"¿Desea realmenete eliminar este contacto?\n(%s %s)"

#warning about log
D_LOG_WARNING_TITLE = u"TorChat: Escritura de eventos activo"
D_LOG_WARNING_MESSAGE = u"La escritura de eventos a archivo esta activada!\n\nArchivo de Eventos: %s\n\nRecuerde eliminar este archivo si ha finalizado con la depuración ya que puede contener información sensible."

#warning about used port
D_WARN_USED_PORT_TITLE = u"TorChat: Puerto actualmente en uso"
D_WARN_USED_PORT_MESSAGE = u"Alguna aplicación, probablemente otra instancia de TorChat, está actualmente escuchando en %s:%s. Debe crear otro perfil con diferentes puertos para poder lanzar una segunda instancia de TorChat"

#warnig about unread messages
D_WARN_UNREAD_TITLE = u"TorChat: Mensajes no leídos"
D_WARN_UNREAD_MESSAGE = u"Hay mensajes no leídos. \n Si continúa se perderán para siempre!\n\n ¿Realmente desea salir de TorChat ahora?"

# Advertencia acerca de amigos en línea
D_WARN_BUDDY_OFFLINE_TITLE = u"TorChat: Amigo en línea"
D_WARN_BUDDY_OFFLINE_MESSAGE = u"Esta operación no es posible con amigos fuera de línea"

# Advertencia acerca de los archivos múltiples
D_WARN_FILE_ONLY_ONE_TITLE = u"TorChat: múltiples archivos"
D_WARN_FILE_ONLY_ONE_MESSAGE = u"No se puede iniciar una transferencia de archivos múltiples en una sola operación. Si desea enviar multiples archivos realice transferencias individuales o compáctalos en un solo archivo"

# Advertencia acerca de guardar el archivo de error
D_WARN_FILE_SAVE_ERROR_TITLE = u"TorChat: Error al guardar el archivo"
D_WARN_FILE_SAVE_ERROR_MESSAGE = u"El archivo '%s' no se pudo crear.\n\n%s"

# aviso sobre el archivo ya existe
D_WARN_FILE_ALREADY_EXISTS_TITLE = u"TorChat: El archivo ya existe"
D_WARN_FILE_ALREADY_EXISTS_MESSAGE = u"El archivo '%s' ya existe. \n¿Desea sobreescribirlo?"

# Diálogo: añadir o modificar contacto
DEC_TITLE_ADD = u"Añadir nuevo contacto"
DEC_TITLE_EDIT = u"Editar contacto"
DEC_TORCHAT_ID = u"TorChat ID"
DEC_DISPLAY_NAME = u"Mostrar nombre"
DEC_INTRODUCTION = u"Introducción"
DEC_MSG_16_CHARACTERS = u"La dirección debe ser de 16 caracteres de longitud, no  %i."
DEC_MSG_ONLY_ALPANUM = u"La dirección sólo puede contener números y letras minúsculas"
DEC_MSG_ALREADY_ON_LIST = u"%s ya está en su lista"

# Diálogo: editar mi perfil
DEP_TITLE = u"Editar mi perfil"
DEP_NAME = u"Nombre"
DEP_TEXT = u"Texto"
DEP_SET_AVATAR = u"Configurar avatar"
DEP_REMOVE_AVATAR = u"Eliminar avatar"
DEP_AVATAR_SELECT_PNG = u"Seleccione un archivo con formato .PNG para usar como tu avatar (se ampliará a 64 * 64, puede contener transparencia)"
DEP_PNG_FILES = u"Archivos de formato PNG"
DEP_ALL_FILES = u"Todos los archivos"
DEP_WARN_TITLE = u"No se pudo seleccionar el avatar"
DEP_WARN_IS_ALREADY = u"El avatar seleccionado ya está disponible"
DEP_WARN_MUST_BE_PNG = u"El avatar debe ser un archivo con formato .PNG"

# Ventana de transferencia de archivos
DFT_FILE_OPEN_TITLE = u"Enviar archivo a %s"
DFT_FILE_SAVE_TITLE = u"Guardar archivo de %s"
DFT_SEND = u"Envíando %s\na %s\n%04.1f%% (%i de %i bytes)"
DFT_RECEIVE = u"Recibiendo %s\nde %s\n%04.1f%% (%i de %i bytes)"
DFT_WAITING = u"en espera de conexión"
DFT_STARTING = u"empezando transferencia"
DFT_ABORTED = u"transferencia abortada"
DFT_COMPLETE = u"transferencia completada"
DFT_ERROR = u"error"

# Configuración dialaog
DSET_TITLE = u"Configuración de TorChat"
DSET_NET_TITLE = u"Red"
DSET_NET_ACTIVE = u"activo"
DSET_NET_INACTIVE = u"inactivo"
DSET_NET_TOR_ADDRESS = u"Dirección IP de Tor"
DSET_NET_TOR_SOCKS = u"Puerto Socks"
DSET_NET_TOR_CONTROL = u"Puerto de Control"
DSET_NET_OWN_HOSTNAME = u"TorChat ID"
DSET_NET_LISTEN_INTERFACE = u"Dirección IP de escucha"
DSET_NET_LISTEN_PORT = u"Puerto de escucha"
DSET_GUI_TITLE = u"Interfaz de usuario"
DSET_GUI_LANGUAGE = u"Idioma"
DSET_GUI_OPEN_MAIN_HIDDEN = u"Iniciar sesión con la ventana principal minimizada"
DSET_GUI_OPEN_CHAT_HIDDEN = u"No abrir automáticamente nuevas ventanas"
DSET_GUI_NOTIFICATION_POPUP = u"Notificación emergente"
DSET_GUI_NOTIFICATION_METHOD = u"Método de notificación"
DSET_GUI_FLASH_WINDOW = u"Título de la ventana fugaz de nuevo mensaje"
DSET_MISC_TITLE = u"Otros"
DSET_MISC_TEMP_IN_DATA = u"Guardar archivos temporales dentro del directorio de datos"
DSET_MISC_TEMP_CUSTOM_DIR = u"Directorio temporal (dejar en blanco para el directorio por defecto del sistema operativo)"

# avisos en la ventana de chat (los corchetes)
NOTICE_DELAYED_MSG_WAITING = u"mensajes demorados en espera de ser enviados"
NOTICE_DELAYED_MSG_SENT = u"mensajes demorados han sido enviados"
NOTICE_DELAYED = u"demorado"

# De mensaje para mensajes fuera de línea
MSG_OFFLINE_TITLE = u"TorChat: mensajes encolados"
MSG_OFFLINE_EMPTY = u"no hay mensajes (más) mensajes encolados para %s"
MSG_OFFLINE_QUEUED = u"mensajes sin conexión encolados para %s:\n\n%s"

# Lista de amigos del ratón emergente hover
BPOP_BUDDY_IS_OFFLINE = u"Amigo está en línea"
BPOP_CONNECTED_AWAITING_RETURN_CONN = u"Conectado, en espera de conexión de retorno ..."
BPOP_CLIENT_SOFTWARE = u"Cliente: %s %s"

# Registro de las conversaciones para presentar
LOG_HEADER = u"Este archivo de registro no está firmado y no hay forma de validar su origen"
LOG_STARTED = u"Escritura de eventos en marcha"
LOG_STOPPED = u"Escritura de eventos detenida"
LOG_DELETED = u"Los archivos de registro se han eliminado"
LOG_IS_ACTIVATED = u"La escritura de eventos a archivo esta activada:\n%s"
LOG_IS_STOPPED_OLD_LOG_FOUND = u"La escritura de eventos se encuentra detenida pero el archivo de registro antiguo todavía existe:\n%s"

# Sobre la caja
ABOUT_TITLE = u"Acerca de TorChat"
ABOUT_TEXT = u"""TorChat %(version)s (svn: r%(svn)s)
  %(copyright)s

Traducciones:
  %(translators)s

Configuración de ambiente:
  Python: %(python)s
  wx: %(wx)s

(N.D.T.: el siguiente bloque no ha sido traducido \
por cuestiones de legales) \

*

TorChat is free software: you can redistribute it and/or \
modify it under the terms of the GNU General Public \
License as published by the Free Software Foundation, \
either version 3 of the License, or (at your option) \
any later version.

TorChat is distributed in the hope that it will be useful, \
but WITHOUT ANY WARRANTY; without even the implied \
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. \
See the GNU General Public License for more details.

*

And now for something completely different:

If you happen to run a software company near Hannover, Germany and \
are in need of a new coder, feel free to regard this little program \
as my application documents and drop me a mail with your answer.
"""
